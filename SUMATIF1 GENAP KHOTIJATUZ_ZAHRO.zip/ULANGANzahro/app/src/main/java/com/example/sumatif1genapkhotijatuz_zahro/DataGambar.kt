package com.example.sumatif1genapkhotijatuz_zahro

class DataGambar (val gambar: Int, val buku :String,val guru :String,val siswa :String,val visi_misi :String)